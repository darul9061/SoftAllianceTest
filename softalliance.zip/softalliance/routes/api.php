<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UseryController;
use App\Http\Controllers\MoviesController;
use App\Http\Controllers\MoviesCreateController;
use App\Http\Controllers\PostCommentController;
use GuzzleHttp\Middleware;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('/login', [UserController::class, 'login']); //->middleware("admin");
Route::post('/signup', [UserController::class, 'signup']);
Route::get('/', [UserController::class, 'index']);

Route::middleware(['auth:sanctum'])->group(function(){

    Route::post('/create', [MoviesCreateController::class, 'store']);
    Route::get('/movies', [MoviesController::class, 'index']);
    Route::post('/postComment', [PostCommentController::class, 'postComment']);
});

Route::get('/home', [MoviesController::class, 'display']);

