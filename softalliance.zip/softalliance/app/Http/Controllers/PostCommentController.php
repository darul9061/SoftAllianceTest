<?php

namespace App\Http\Controllers;

use Illuminate\Auth\Events\Validated;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Movies;
use App\Models\Comments;

class PostCommentController extends Controller
{

    public function postComment(Request $request){
        //
        $details = $request->validate([
            'movie_id' => ['required', 'integer'],
            'comment' => ['required', 'string'],
        ]);

        $movieAvailable = Movies::find($request->movie_id);

        if(!empty($movieAvailable)){
            $user_id = $request->user()->id;
            $comment = new Comments();
            $comment->movie_id = $request->movie_id;
            $comment->comment = $request->comment;
            $comment->user_id = $user_id;
            $comment->save();

            return response([
                "status" => true,
                "message" => "Success",
                "movies" => $comment
            ]);
        }else{
            
            return response([
                "status" => false,
                "message" => "Movie Unavailable"
            ], 404);
        }
    }
}
