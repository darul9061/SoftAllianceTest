<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Movies;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Storage;

class MoviesCreateController extends Controller
{

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $details = $request->validate([
            'name' => ['bail', 'required', 'string'],
            'description' => ['required','string'],
            'release_date' => ['required', 'date'],
            'rating' => ['bail', 'required', 'integer'],
            'ticket_price' => ['required','integer'],
            'country' => ['required', 'string'],
            'genre' => ['required','string', 'unique:users,email'],
        ]);

        $movies = new Movies();
        $movies->name = $request->name;
        $movies->description = $request->description;
        $movies->release_date = $request->release_date;
        $movies->rating = $request->rating;
        $movies->ticket_price = $request->ticket_price;
        $movies->country = $request->country;

        $uploadedFile = $request->file('photo');
        $filename = Uniqid(Str::random(10));
        // $filename = time().$uploadedFile->getClientOriginalName();
        $fileType = $uploadedFile->getClientOriginalExtension();

        Storage::disk('local')->putFileAs(
            'files/',
            $uploadedFile,
            "$filename." . "$fileType"
        );

        $movies->photo =  "storage/app/files/$filename." . "$fileType";
        $movies->save();

        return response([
            "status" => true,
            "message" => "Success",
            "movies" => $movies
        ]);
    }

}
