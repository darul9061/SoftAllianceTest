<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Admin extends Controller
{
    //

    public function login(Request $request){
        $details = $request->validate([
            // 'name' => ['bail', 'required', 'max:25'],
            'email' => ['bail', 'required','string'],
            'password' => ['bail', 'required', 'string'],
        ]); 
        

        if(Auth::attempt($details)){

            $token = $request->user()->createToken($details['email']);
            return response(array_merge([
                'message' => "success",
                'status' => true
            ], [
                "user" => $request->user(),
                "token" => $token->plainTextToken
            ]));
        }else{
            return response([
                'message' => "Wrong details",
                'status' => false
            ], 401);
        }
    }
}
