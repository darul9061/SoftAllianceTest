<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Movies;
use App\Models\Comments;
use Illuminate\Support\Facades\Auth;

class MoviesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //get all movies
        $movies = Movies::with(['comments', 'genres'])->get();

        if(!Auth::check()){
            
            abort(401, "Unauthorized");
        }

        return response([
            "user" => Auth::user(),
            "movies" => $movies
        ]);
        // foreach($movies as movie){

        // }
    }

    public function display(Request $request)
    {
        //get all movies
        $top = Movies::where("rating", 4)
                        ->orWhere("rating", 5)
                        ->with(['comments', 'genres'])
                        ->limit(4)
                        ->get();

        $new = Movies::with(['comments', 'genres'])
                        ->limit(4)
                        ->get();

        $random = Movies::with(['comments', 'genres'])
                        ->inRandomOrder()
                        ->limit(4)
                        ->get();

        return response(array_merge([
            'message' => "success",
            'status' => true
        ],  [
                "user" => Auth::user(),
                "movies" => [
                    "top" => $top,
                    "new" => $new,
                    "random" => $random
                ]
        ]));
        // foreach($movies as movie){

        // }
    }

}
