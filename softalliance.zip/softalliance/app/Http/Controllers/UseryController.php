<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\Usery;

class UseryController extends Controller
{
    //

    public function login(Request $request){
        $details = $request->validate([
            'ername' => ['bail', 'required', 'max:40'],
            // 'secrets' => ['required'],
            'password' => ['bail'],
        ]);

        // $details['password'] = Hash::make($details['password'] );

        // $token = null;
        if(!Auth::attempt($details, false) )
        {
            $res = array("response" => 'Wrong Username or Password');
            // $res["message"] = "Email or Password Incorrect";
            // $res["data"] = $request->ername;
            // $res["status"] = false;
            // $res["details"] = $details;
            // $res["hashPassword"] = $details['secrets'];
            // $res["secrets"] = Hash::check($request->secrets, $details['secrets'] );
            return response($res, 401);

        }else{
            $request->session()->regenerate();
            $user = Auth::user();

            $res = array("response" => 'success',
                    
                "data" => [ $user['ername'], $user['first_one'], $user['last_one'], $user['ail'], $user['nums'] ]
            );
            return $res;
            // $token = $request->user()->createToken($request->password);
            // return [
            //     "user" => $user,
            //     "token" => $token->plainTextToken,
            // ];
        }
        // return [
            // "user" => $details,
            // "token" => $token
        // ];
    }

    public function signuup(Request $request){
        
    }
}
?>