<?php

namespace App\Http\Controllers;

use Illuminate\Auth\Events\Validated;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{

    public function index(Request $request){
        //tests
        return View('TestApi');
    }

    public function signup(Request $request){
        $details = $request->validate([
            'name' => ['bail', 'required'],
            'email' => ['bail', 'required','string', 'unique:users,email'],
            'password' => ['bail', 'required', 'string'],
            // 'email' => ['required', 'unique:users']
        ]);

        $passwordH = Hash::make($details['password'] );
        $user = User::create([
            'name' => $details['name'],
            'email' => $details['email'],
            'password' => $passwordH
        ]);

        $token = $user->createToken($details['email']);
        return response(array_merge([
            'message' => "success",
            'status' => true
        ], [
            "user" => $details,
            "token" => $token->plainTextToken
        ]));
    }

    public function login(Request $request){
        $details = $request->validate([
            // 'name' => ['bail', 'required', 'max:25'],
            'email' => ['bail', 'required','string'],
            'password' => ['bail', 'required', 'string'],
        ]); 
        

        if(Auth::attempt($details)){

            $token = $request->user()->createToken($details['email']);
            return response(array_merge([
                'message' => "success",
                'status' => true
            ], [
                "user" => $request->user(),
                "token" => $token->plainTextToken
            ]));
        }else{
            return response([
                'message' => "Wrong details",
                'status' => false
            ], 401);
        }
    }
}
