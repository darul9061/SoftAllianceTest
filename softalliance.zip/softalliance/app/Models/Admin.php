<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;

class Admin extends Authenticable
{
    use HasApiTokens, HasFactory, Notifiable;
    
    // function to change default "password" to new column for passwords
    public function getAuthPassword(){
        return $this->secrets;
    }
}
