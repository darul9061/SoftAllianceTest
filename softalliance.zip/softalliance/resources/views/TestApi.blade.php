<!DOCTYPE html>
    <head>
        <title>
            Test Laravel
        </title>
    </head>
    <body>
        <form action="/" method="post">
            <input type="text" name="email">
            <input type="password" name="password">
            <input type="text" name="name">
            <button> Submit </button>
        </form>
    </body>
</html>
